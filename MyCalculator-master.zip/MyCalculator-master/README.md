# CalculatriceAndroidApp

  ![Calculatrice Image](https://raw.githubusercontent.com/Nossayr/MyCalculator/master/calculatrice.png?token=GHSAT0AAAAAACBHBYQSX3WTXEY3R3ID6P4KZBUDFVQ)

<p>Realiser par : <strong>EL-MALIKY Nossayr<strong></p>
<p>Professeur : <strong>KHAMLICHI Youness <strong></p>
